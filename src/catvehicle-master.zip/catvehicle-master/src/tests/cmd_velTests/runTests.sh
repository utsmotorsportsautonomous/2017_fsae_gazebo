#!/bin/bash

./cmdSimpleTest.sh catvehicle

./cmdTireTest.sh catvehicle


