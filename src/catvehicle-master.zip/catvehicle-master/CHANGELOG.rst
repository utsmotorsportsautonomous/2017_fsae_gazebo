^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package catvehicle
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.2 (2017-02-02)
------------------
* Removed worlds intended for the cvchallenge_task2 repository
* Contributors: Jonathan Sprinkle
